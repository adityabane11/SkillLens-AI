"""Vercel serverless entry point for the SkillLens AI Flask application."""
from app import app
